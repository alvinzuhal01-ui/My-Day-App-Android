package com.myday.family

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("myday", Context.MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web=findViewById(R.id.webview)
        web.settings.javaScriptEnabled=true
        web.settings.domStorageEnabled=true
        web.settings.databaseEnabled=true
        web.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean{
                val base=prefs.getString("server_url","") ?: ""
                return if(base.isNotBlank() && r.url.toString().startsWith(base)) false
                else { startActivity(Intent(Intent.ACTION_VIEW,r.url)); true }
            }
        }
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),44)
        val saved=prefs.getString("server_url",null)
        if(saved.isNullOrBlank()) askServer() else web.loadUrl(saved)
    }
    private fun askServer(){
        val input=android.widget.EditText(this)
        input.hint="https://your-private-myday-server/"
        AlertDialog.Builder(this).setTitle("Connect My Day")
            .setMessage("Enter your family's HTTPS My Day server address.")
            .setView(input).setCancelable(false)
            .setPositiveButton("Connect"){_,_-> val s=input.text.toString().trim().let{if(it.endsWith("/"))it else "$it/"}
                prefs.edit().putString("server_url",s).apply(); web.loadUrl(s)}
            .show()
    }
    override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}
}
