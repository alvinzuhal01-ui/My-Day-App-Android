plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.myday.family"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.myday.family"
        minSdk = 26
        targetSdk = 36
        versionCode = 10
        versionName = "10.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.webkit:webkit:1.14.0")
}
