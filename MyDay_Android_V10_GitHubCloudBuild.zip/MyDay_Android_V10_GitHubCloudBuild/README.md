# My Day Android V10 — GitHub Cloud Build

This version is prepared so you can build the APK using only your Android phone. No Android Studio is required.

## Phone-only process
1. Create a GitHub repository.
2. Upload the contents of this ZIP, including `.github/workflows/build-apk.yml`.
3. Commit to `main`.
4. Open GitHub → your repository → Actions.
5. Open **Build My Day APK**.
6. Wait for the green check.
7. Open the completed run and download the **MyDay-debug-apk** artifact.
8. Extract it and install `app-debug.apk` on your Samsung.

GitHub Actions runs the Gradle build on a hosted runner, and GitHub Actions artifacts can be downloaded after the workflow completes.

## App
The APK is the Android client. It connects to your My Day family server over HTTPS. It does not contain the shared server/database.

First launch asks for the server HTTPS address.

## Important
This creates a DEBUG APK for personal testing. For a public release, use a private signing key stored in GitHub Actions Secrets and build a signed release APK/AAB. Never put a keystore/password in the repository.

The project uses Android Gradle Plugin 8.13 and Gradle 8.13. Android's Gradle build system is the standard build mechanism for APKs.
